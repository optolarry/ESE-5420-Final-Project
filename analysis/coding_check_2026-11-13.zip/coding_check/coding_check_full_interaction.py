"""Development-only: 5-fold CV on all training data for the interaction design under three codings.
Same outer folds (seed 42) and inner tuning seeds (42+fold) as the paper. Training data only."""
import sys, runpy
import numpy as np, pandas as pd
from sklearn.model_selection import KFold
SRC, OUT = sys.argv[1], sys.argv[2]
ns = {}
src = open(sys.argv[3]).read().split("V = [('ref_std', 'OLS')")[0]      # reuse definitions only
sys.argv = [sys.argv[0], SRC, OUT, '']
exec(compile(src, 'defs', 'exec'), ns)
d, fitpred, rmse, signflip = ns['d'], ns['fitpred'], ns['rmse'], ns['signflip']
V = [('add', 'ref_std', 'OLS'), ('add', 'full_raw', 'Ridge'), ('interaction', 'ref_std', 'OLS'), ('interaction', 'ref_std', 'Ridge'),
     ('interaction', 'full_std', 'Ridge'), ('interaction', 'full_raw', 'Ridge')]
oof = {v: np.zeros(len(d)) for v in V}; fr = {v: [] for v in V}
for fold, (ti, vi) in enumerate(KFold(5, shuffle=True, random_state=42).split(d), 1):
    a, b = d.iloc[ti], d.iloc[vi]
    for v in V:
        p = fitpred(a, b, v[1], v[0], v[2], 42 + fold); oof[v][vi] = p; fr[v].append(rmse(b.y, p))
y = d.y.to_numpy(); rng = np.random.default_rng(42); base = ('add', 'ref_std', 'OLS'); rows = []
for v in V:
    rows.append({'design': v[0], 'coding': v[1], 'method': v[2], 'cv_rmse': rmse(y, oof[v]), 'fold_sd': float(np.std(fr[v], ddof=1)),
                 'delta_vs_additive_OLS': rmse(y, oof[v]) - rmse(y, oof[base]),
                 'p_better_than_additive_OLS': None if v == base else signflip((y - oof[base]) ** 2 - (y - oof[v]) ** 2, rng),
                 'folds_better': None if v == base else int(sum(x < z for x, z in zip(fr[v], fr[base])))})
out = pd.DataFrame(rows); out.to_csv(OUT, index=False); pd.set_option('display.width', 250); print(out.round(5).to_string(index=False))
