"""Same development-only check for the interaction design (training data only).
Small training subsets validated on the rest of the training data; ridge tuned inside the subset.
Also a sign-flip test of ridge (full_raw) against OLS (full_std) on per-sale differences averaged over the five subsets' common validation rows is not possible (validation rows differ), so per-subset tests are reported."""
import sys
import numpy as np, pandas as pd
sys.path.insert(0, sys.argv[3])
import importlib.util
SRC, OUT = sys.argv[1], sys.argv[2]
from sklearn.model_selection import KFold
NUM = ['log_gross', 'log_land', 'age', 'units', 'month']
GRID = np.array([10 ** (k / 2) for k in range(-4, 13)])
d = pd.read_csv(SRC, parse_dates=['SALE DATE']); d = d[d['SALE DATE'] < '2026-07-01'].reset_index(drop=True)
for c in ['NEIGHBORHOOD', 'BUILDING CLASS CATEGORY']: d[c] = d[c].astype(str).str.strip()
d['log_gross'] = np.log(d['GROSS SQUARE FEET']); d['log_land'] = np.log(d['LAND SQUARE FEET'])
d['age'] = 2026 - d['YEAR BUILT']; d['units'] = d['TOTAL UNITS']; d['month'] = d['SALE DATE'].dt.month; d['y'] = np.log(d['SALE PRICE'])
assert len(d) == 10737

class Enc:
    def __init__(self, coding, kind): self.coding, self.kind = coding, kind
    def _raw(self, df):
        cut = 1 if self.coding == 'ref_std' else 0
        b = np.column_stack([(df['BUILDING CLASS CATEGORY'] == v).to_numpy(float) for v in self.bc[cut:]])
        n = np.column_stack([(df.NEIGHBORHOOD == v).to_numpy(float) for v in self.nb[cut:]])
        parts = [df[NUM].to_numpy(float), b, n]
        if self.kind == 'interaction': parts.append((n[:, :, None] * b[:, None, :]).reshape(len(df), -1))
        return np.column_stack(parts)
    def fit(self, df):
        self.bc = sorted(df['BUILDING CLASS CATEGORY'].unique()); self.nb = sorted(df.NEIGHBORHOOD.unique())
        x = self._raw(df); self.keep = x.std(0) > 1e-12; x = x[:, self.keep]; self.mu = x.mean(0); self.sd = x.std(0)
        if self.coding == 'full_raw':
            isnum = np.zeros(len(self.keep), bool); isnum[:len(NUM)] = True; isnum = isnum[self.keep]
            self.mu = np.where(isnum, self.mu, 0.0); self.sd = np.where(isnum, self.sd, 1.0)
        return self
    def transform(self, df): return (self._raw(df)[:, self.keep] - self.mu) / self.sd

def ridge_path(x, y, z, grid):
    xm, ym = x.mean(0), y.mean(); xc = x - xm
    eig, vec = np.linalg.eigh(xc.T @ xc); rhs = vec.T @ (xc.T @ (y - ym))
    return ym + ((z - xm) @ vec) @ (rhs[:, None] / (np.maximum(eig, 0)[:, None] + grid))
def ols(x, y, z):
    xm, ym = x.mean(0), y.mean(); return ym + (z - xm) @ np.linalg.lstsq(x - xm, y - ym, rcond=None)[0]
def tune(df, coding, kind, seed):
    err = np.zeros(len(GRID))
    for ti, vi in KFold(5, shuffle=True, random_state=seed).split(df):
        a, b = df.iloc[ti], df.iloc[vi]; e = Enc(coding, kind).fit(a)
        err += ((b.y.to_numpy()[:, None] - ridge_path(e.transform(a), a.y.to_numpy(), e.transform(b), GRID)) ** 2).sum(0)
    return int(np.argmin(err))
def fitpred(a, b, coding, kind, method, seed):
    e = Enc(coding, kind).fit(a); x, z = e.transform(a), e.transform(b)
    if method == 'OLS': return ols(x, a.y.to_numpy(), z)
    return ridge_path(x, a.y.to_numpy(), z, GRID[[tune(a, coding, kind, seed)]])[:, 0]
def signflip(diff, rng, flips=10000):
    obs, cnt = diff.mean(), 0
    for _ in range(0, flips, 500): cnt += int(((rng.choice([-1., 1.], size=(500, len(diff))) * diff).mean(1) >= obs).sum())
    return cnt / flips
rmse = lambda y, p: float(np.sqrt(np.mean((np.asarray(y) - p) ** 2)))
V = [('ref_std', 'OLS'), ('ref_std', 'Ridge'), ('full_std', 'OLS'), ('full_raw', 'Ridge')]
rng = np.random.default_rng(42); rows = []
for kind in ['add', 'interaction']:
    for n in [500, 1000, 2000, 5000]:
        for seed in [42, 43, 44, 45, 46]:
            ix = np.random.default_rng(seed).choice(len(d), n, replace=False); mask = np.zeros(len(d), bool); mask[ix] = True
            a, b = d.iloc[ix], d[~mask]; yb = b.y.to_numpy(); P = {v: fitpred(a, b, v[0], kind, v[1], seed) for v in V}
            r = {'design': kind, 'n': n, 'seed': seed, **{'/'.join(v): rmse(yb, P[v]) for v in V}}
            r['p_paper_ridge_vs_ols'] = signflip((yb - P[('ref_std', 'OLS')]) ** 2 - (yb - P[('ref_std', 'Ridge')]) ** 2, rng)
            r['p_fair_ridge_vs_ols'] = signflip((yb - P[('full_std', 'OLS')]) ** 2 - (yb - P[('full_raw', 'Ridge')]) ** 2, rng)
            rows.append(r)
runs = pd.DataFrame(rows); runs.to_csv(OUT, index=False)
cols = ['/'.join(v) for v in V]
g = runs.groupby(['design', 'n'])[cols].mean()
g['gain_paper_coding'] = g['ref_std/OLS'] - g['ref_std/Ridge']; g['gain_fair_coding'] = g['full_std/OLS'] - g['full_raw/Ridge']
g['fair_wins'] = runs.assign(w=runs['full_raw/Ridge'] < runs['full_std/OLS']).groupby(['design', 'n']).w.sum()
g['fair_p<0.05'] = runs.assign(w=runs.p_fair_ridge_vs_ols < 0.05).groupby(['design', 'n']).w.sum()
g['paper_p<0.05'] = runs.assign(w=runs.p_paper_ridge_vs_ols < 0.05).groupby(['design', 'n']).w.sum()
pd.set_option('display.width', 250); print(g.round(4).to_string())
