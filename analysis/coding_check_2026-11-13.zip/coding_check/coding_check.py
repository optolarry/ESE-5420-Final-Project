"""Development-only check of how categorical inputs are coded for penalized models.

Uses ONLY sales before 2026-07-01 (the training data). The July-August test set
and any later data are never read into a model or scored.

Codings compared for the additive design:
  ref_std     reference coding (first level dropped), every column standardized  [as in the paper]
  full_std    one indicator per level (no reference), every column standardized
  full_raw    one indicator per level, indicators left as 0/1, numeric inputs standardized
A level unseen in the fit data gets all-zero indicators (ref_std: the reference level).

Part 1: 5-fold CV on all training data (same folds as the paper, seed 42), ridge
        tuned by inner 5-fold CV (seed 42+fold).
Part 2: small training subsets (500..5000, seeds 42-46) validated on the REST of
        the training data, ridge tuned inside the subset.
Part 3: structural + borough OLS as an intermediate model (5-fold CV).
"""
import sys, json
import numpy as np, pandas as pd
from sklearn.model_selection import KFold

SRC, OUT = sys.argv[1], sys.argv[2]
NUM = ['log_gross', 'log_land', 'age', 'units', 'month']
GRID = np.array([10 ** (k / 2) for k in range(-4, 13)])  # 1e-2 .. 1e6, as in the paper

d = pd.read_csv(SRC, parse_dates=['SALE DATE'])
d = d[d['SALE DATE'] < '2026-07-01'].reset_index(drop=True)      # training data only
for c in ['NEIGHBORHOOD', 'BUILDING CLASS CATEGORY', 'BOROUGH']: d[c] = d[c].astype(str).str.strip()
d['log_gross'] = np.log(d['GROSS SQUARE FEET']); d['log_land'] = np.log(d['LAND SQUARE FEET'])
d['age'] = 2026 - d['YEAR BUILT']; d['units'] = d['TOTAL UNITS']; d['month'] = d['SALE DATE'].dt.month
d['y'] = np.log(d['SALE PRICE'])
assert len(d) == 10737, len(d)

class Enc:
    def __init__(self, coding, cats): self.coding, self.cats = coding, cats
    def _raw(self, df):
        parts = [df[NUM].to_numpy(float)]
        for c in self.cats:
            lv = self.levels[c][1:] if self.coding == 'ref_std' else self.levels[c]
            parts.append(np.column_stack([(df[c] == v).to_numpy(float) for v in lv]) if lv else np.zeros((len(df), 0)))
        return np.column_stack(parts)
    def fit(self, df):
        self.levels = {c: sorted(df[c].unique()) for c in self.cats}
        x = self._raw(df); self.keep = x.std(0) > 1e-12; x = x[:, self.keep]
        self.mu = x.mean(0); self.sd = x.std(0)
        if self.coding == 'full_raw':                      # leave indicators as 0/1
            isnum = np.zeros(len(self.keep), bool); isnum[:len(NUM)] = True
            isnum = isnum[self.keep]; self.mu = np.where(isnum, self.mu, 0.0); self.sd = np.where(isnum, self.sd, 1.0)
        return self
    def transform(self, df): return (self._raw(df)[:, self.keep] - self.mu) / self.sd

def ridge_path(x, y, z, grid):
    """Predictions on z for every penalty in grid (intercept unpenalized)."""
    xm, ym = x.mean(0), y.mean(); xc = x - xm
    eig, vec = np.linalg.eigh(xc.T @ xc); rhs = vec.T @ (xc.T @ (y - ym))
    return ym + ((z - xm) @ vec) @ (rhs[:, None] / (np.maximum(eig, 0)[:, None] + grid))

def ols(x, y, z):
    xm, ym = x.mean(0), y.mean()
    return ym + (z - xm) @ np.linalg.lstsq(x - xm, y - ym, rcond=None)[0]

def tune(df, coding, cats, seed):
    err = np.zeros(len(GRID))
    for ti, vi in KFold(5, shuffle=True, random_state=seed).split(df):
        a, b = df.iloc[ti], df.iloc[vi]; e = Enc(coding, cats).fit(a)
        err += ((b.y.to_numpy()[:, None] - ridge_path(e.transform(a), a.y.to_numpy(), e.transform(b), GRID)) ** 2).sum(0)
    return int(np.argmin(err))

def fitpred(a, b, coding, cats, method, seed):
    e = Enc(coding, cats).fit(a); x, z = e.transform(a), e.transform(b)
    if method == 'OLS': return ols(x, a.y.to_numpy(), z), None
    j = tune(a, coding, cats, seed)
    return ridge_path(x, a.y.to_numpy(), z, GRID[[j]])[:, 0], float(GRID[j])

rmse = lambda y, p: float(np.sqrt(np.mean((np.asarray(y) - p) ** 2)))
ADD = ['BUILDING CLASS CATEGORY', 'NEIGHBORHOOD']
VARIANTS = [('ref_std', 'OLS'), ('full_std', 'OLS'), ('ref_std', 'Ridge'), ('full_std', 'Ridge'), ('full_raw', 'Ridge')]
res = {}

# ---- Part 1: 5-fold CV on all training data
oof = {v: np.zeros(len(d)) for v in VARIANTS}; rows = []
for fold, (ti, vi) in enumerate(KFold(5, shuffle=True, random_state=42).split(d), 1):
    a, b = d.iloc[ti], d.iloc[vi]
    unseen = int((~b.NEIGHBORHOOD.isin(a.NEIGHBORHOOD)).sum())
    for v in VARIANTS:
        p, lam = fitpred(a, b, v[0], ADD, v[1], 42 + fold); oof[v][vi] = p
        rows.append({'fold': fold, 'coding': v[0], 'method': v[1], 'rmse': rmse(b.y, p), 'lambda': lam, 'unseen_rows': unseen})
part1 = pd.DataFrame(rows)
summ = [{'coding': c, 'method': m, 'cv_rmse': rmse(d.y, oof[(c, m)]),
         'fold_sd': part1[(part1.coding == c) & (part1.method == m)].rmse.std(ddof=1)} for c, m in VARIANTS]
res['part1'] = pd.DataFrame(summ)

def signflip(diff, rng, flips=10000):
    obs, cnt = diff.mean(), 0
    for _ in range(0, flips, 500):
        cnt += int(((rng.choice([-1., 1.], size=(500, len(diff))) * diff).mean(1) >= obs).sum())
    return float(obs), cnt / flips
rng = np.random.default_rng(42); y = d.y.to_numpy(); e2 = {v: (y - oof[v]) ** 2 for v in VARIANTS}
pairs = [(('full_raw', 'Ridge'), ('ref_std', 'OLS')), (('full_std', 'Ridge'), ('ref_std', 'OLS')),
         (('full_raw', 'Ridge'), ('ref_std', 'Ridge')), (('ref_std', 'Ridge'), ('ref_std', 'OLS'))]
res['part1_tests'] = pd.DataFrame([{'A': '/'.join(a), 'B': '/'.join(b), 'delta_rmse': rmse(y, oof[a]) - rmse(y, oof[b]),
                                    'p_A_better': signflip(e2[b] - e2[a], rng)[1]} for a, b in pairs])

# ---- Part 2: small training subsets, validated on the rest of the training data
rows = []
for n in [500, 1000, 2000, 5000]:
    for seed in [42, 43, 44, 45, 46]:
        ix = np.random.default_rng(seed).choice(len(d), n, replace=False)
        mask = np.zeros(len(d), bool); mask[ix] = True
        a, b = d.iloc[ix], d[~mask]
        unseen = float((~b.NEIGHBORHOOD.isin(a.NEIGHBORHOOD)).mean())
        for v in VARIANTS:
            p, lam = fitpred(a, b, v[0], ADD, v[1], seed)
            rows.append({'n': n, 'seed': seed, 'coding': v[0], 'method': v[1], 'rmse': rmse(b.y, p), 'lambda': lam, 'unseen_share': unseen})
part2 = pd.DataFrame(rows); res['part2_runs'] = part2
res['part2'] = part2.groupby(['n', 'coding', 'method']).agg(mean_rmse=('rmse', 'mean'), sd=('rmse', 'std'), unseen_share=('unseen_share', 'mean')).reset_index()

# ---- Part 3: borough as an intermediate step (OLS, reference coding as in the paper)
rows = []
for name, cats in [('structural', ['BUILDING CLASS CATEGORY']), ('structural+borough', ['BUILDING CLASS CATEGORY', 'BOROUGH']), ('additive', ADD)]:
    p = np.zeros(len(d))
    for ti, vi in KFold(5, shuffle=True, random_state=42).split(d):
        p[vi] = fitpred(d.iloc[ti], d.iloc[vi], 'ref_std', cats, 'OLS', 0)[0]
    rows.append({'model': name, 'cv_rmse': rmse(d.y, p)})
res['part3'] = pd.DataFrame(rows)

pd.set_option('display.width', 220); pd.set_option('display.max_rows', 200)
with pd.ExcelWriter(OUT) if OUT.endswith('.xlsx') else open(OUT, 'w') as f:
    for k, v in res.items():
        txt = f'== {k}\n{v.to_string(index=False)}\n\n'
        print(txt, end=''); f.write(txt)
for k, v in res.items(): v.to_csv(OUT.replace('.txt', f'_{k}.csv'), index=False)
ref = sorted(d.NEIGHBORHOOD.unique())[0]
print('reference neighborhood (all training data):', ref, '| its sales:', int((d.NEIGHBORHOOD == ref).sum()), '| neighborhoods:', d.NEIGHBORHOOD.nunique())
